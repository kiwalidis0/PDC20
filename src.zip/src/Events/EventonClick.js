import React, {useState} from "react";

function EventOnClick(){
    // For Target
    const[inputValue, setInputValue] = useState('');
    const handleChange = (event) => {
        setInputValue(event.target.value);
        console.log(event.target.value);
    }

    // For Type
    const handleEvent = (event) => {
        event.stopPropagation(); // This will stop the event propagating further 
        console.log(`Event type: ${event.type}`)
        handleClick();
    }
    
    // PreventDefault
    const handleSubmit = (event) => {
        event.preventDefault();
        console.log("Form submission prevented")
        // You can add additional form handling 
    };

    
    const handleClick = () => {
        alert("Button Clicked!");
    }

   return(
    <form onSubmit={handleSubmit}>
        <div>
            <input type="text" onChange={handleChange}/>
            <button onClick={handleEvent}>Click me!</button>
            <button type="submit">Submit</button>
        </div>
    </form>
   );
}

export default EventOnClick;