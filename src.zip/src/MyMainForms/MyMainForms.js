import React from "react";
import BasicForms from "./BasicForms";
import { Route, Routes, Link } from "react-router-dom";
import ControlledInput from "./ControlledInput";
import UncontrolledInput from "./UncontrolledInput";
import './MyMainForm.css';
import TabbedForm from "./TabForm/TabbedForm";

const MyMainForms = () => {
    return (
        <div className="container">
    <h1>React Forms App</h1>
    <div>
        <nav className="nav nav-pills justify-content-center mb-4">
            <Link className="nav-link" to="basic-form">Basic Form</Link>
            <Link className="nav-link" to="controlled-input">Controlled Input</Link>
            <Link className="nav-link" to="uncontrolled-input">Uncontrolled Input</Link>
            <Link className="nav-link" to="tabbed-form">Tabbed Form</Link>
        </nav>
    </div>

            <div className="content">
                <Routes>
                    <Route path="basic-form" element={<BasicForms />} />
                    <Route path="controlled-input" element={<ControlledInput />} />
                    <Route path="uncontrolled-input" element={<UncontrolledInput />} />
                    <Route path="tabbed-form" element={<TabbedForm />} />
                </Routes>
            </div>
        </div>
    );
};

export default MyMainForms;
