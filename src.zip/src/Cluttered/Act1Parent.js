import React from "react";
import "./Act1Parent.css";

function ActParent(){
    return(
        <div className="container">
            <h1>Siopao!</h1>
        </div>
    );
}

export default ActParent;