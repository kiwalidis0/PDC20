import React from "react";

function Hi(){
    return (
        <div>
            <p>Hi! Andreas Luy!</p>
        </div>
    );
}

export default Hi;