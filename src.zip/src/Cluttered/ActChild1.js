import React from "react";
import "./ActChild.css";

function ActChild1(){
    return(
        <div className="title">
            <h2>The Filipino Steamed Bun with a Rich History</h2>
            <br></br>
            <p>By Blank</p>
        </div>
    );
}

export default ActChild1;