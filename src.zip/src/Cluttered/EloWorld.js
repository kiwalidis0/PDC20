import React from 'react';

function EloWorld(){
    return (
        <div>
            <h2>Wello Horld</h2>
        </div>
    )
}

export default EloWorld;