import React from "react";
import './myhome.css'; 
import reactImage from './react.png';

const MyHome = () => {
    return (
        <div className="header-container text-center mb-3">
            <h1 className="large-header">Welcome to the Home Page</h1>
            <p>This is the Home Page of the simple navigation example</p>
            <div id="carouselExample" class="carousel slide">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src={reactImage} class="d-block w-100" alt="..."/>
                    </div>
                    <div class="carousel-item">
                        <img src={reactImage} class="d-block w-100" alt="..."/>
                    </div>
                </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
            </div>
        </div>
    );
};

export default MyHome;
