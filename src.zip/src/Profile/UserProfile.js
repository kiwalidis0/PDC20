import React, {useState} from "react";
import Navagation from "./Navigation";
import Profile from "./Profile";
import './UserProfile.css'; 
import Form from './Form';

function UserProfilePage(){
    const [userData, setUserData] = useState({      //Initialize state for user data
        name: 'Juan Dela Cruz',
        username: 'mang juan',
        email: 'juan@gmail.com',
    });

    const handleUpdate = (updateInfo) => {
        setUserData ((prevState) => ({
            ...prevState,   // Shallow copying from Form.js
            ...updateInfo,  // Margin to Profile,js
        }));
    };

    return(
        <div>
            <Navagation/>
            <Profile user={userData}/>
            <Form user={userData} onUpdate={handleUpdate}/>
        </div>  
    );
}

export default UserProfilePage;