import React from "react";
import propTypes from 'prop-types';

function Profile({user: {name, username,email}}){
    return(
        <div className="profile">
            <h2>{name}</h2>
            <h2>{username}</h2>
            <p>{email}</p>
        </div>
    );
}

Profile.propTypes = {
    user: propTypes.shape({
        name: propTypes.string.isRequired,
        username: propTypes.string.isRequired,
        email: propTypes.string.isRequired,
    }).isRequired
}
export default Profile;