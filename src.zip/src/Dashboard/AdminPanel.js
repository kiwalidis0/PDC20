import React from "react";
import { Link } from "react-router-dom";

function AdminPanel({ user }) {
    return (
        <div>
            {user.isAdmin ? (
                <div>
                    <h1>Admin Dashboard</h1>
                    <p>Welcome, {user.name}! You have admin powers</p>
                    <button>Manage Users</button>
                    <button>View Reports</button>
                </div>
            ) : (
                <div>
                    <h1>Guest Dashboard</h1>
                    <p>Welcome, {user.name}! You are not admin</p>
                    <Link to="/profile">
                        <button>View Profile</button>
                    </Link>
                    <button>Settings</button>
                </div>
            )}
        </div>
    );
}

export default AdminPanel;
